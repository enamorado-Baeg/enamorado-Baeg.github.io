const saldo = document.querySelectorAll('.saldo');
const symbols = ['', '♠', '♣', '♥', '♦'];
const reverso = document.querySelector('.reverso');
const valorSumado = document.querySelector('.valorSumado');
const mano = document.querySelector('.mano');
const manoVs = document.querySelector('.manoVs');
const acciones = document.querySelector('.acciones');
const status = document.querySelector('.status');
const coins = document.querySelectorAll('.coins .coin');
const apuestaPrevia = document.querySelector('.apuestaPrevia');
const hacerApuesta = document.querySelector('.hacerApuesta');
const coinApostado = document.querySelector('.coinApostado');
const valorSumadoVs = document.querySelector('.valorSumadoVs');
let sumadoVs = 0;
let apostado = 0;
let cartaPosX = 0;
let cartaVsPosX = 0;
let sumado = 0;
let conteo = 0;
let fin = false;

/* Funciones globales */

function update() {
  saldo.forEach(saldoo => {
    saldoo.textContent = '€' + localStorage.saldo;
  });
}
update();

function borrar() {
  localStorage.saldo = parseFloat(localStorage.saldo) + parseFloat(apostado);
  apostado = 0;
  apuestaPrevia.textContent = '€' + apostado;
  update();
}

function restart() {
  apostado = 0;
  cartaPosX = 0;
  sumado = 0;
  apuestaPrevia.textContent = '€' + apostado;
  mano.innerHTML = '';

  manoVs.innerHTML = '';
  cartaVsPosX = 0;
  sumadoVs = 0;
  conteo = 0;
  status.textContent = 'Repartiendo...'
  fin = false;
  update();
  undisabled(hacerApuesta);
}

function disabled(elemento) {
  elemento.style.display = 'none';
}

function undisabled(elemento) {
  elemento.style.display = 'block';
}

function pierde(stt) {
  status.textContent = stt;
  setTimeout(() => {
    alert(`Perdiste, Toca aquí para continuar`);
    restart();
  }, 1500);
}

function empate() {
  status.textContent = 'Doble BlackJack, Empate';
  localStorage.saldo = parseFloat(localStorage.saldo) + parseFloat(apostado);
  setTimeout(() => {
    alert('Ambos Ganan');
    restart();
  }, 1500);
}

function gana(stt) {
  status.textContent = stt;
  localStorage.saldo = parseFloat(localStorage.saldo) + parseFloat(apostado * 2);
  setTimeout(() => {
    alert(`Ganas ${apostado*2}, Toca aquí para continuar`);
    restart();
  }, 1500);
}

function mult() {
  if (localStorage.saldo >= apostado) {
    localStorage.saldo -= apostado;
    apostado = apostado * 2;
    coinApostado.textContent = apostado;
    fin = true;
    nuevaCarta(mano);
    setTimeout(() => {
      nuevaCarta(manoVs);
      verify();
    }, 1000);
  } else {
    alert('No tienes suficiente dinero para multiplicar tu apusta x2');
  }
  update();
}

function pedir() {
  acciones.style.display = 'none';
  nuevaCarta(mano);
  verify();
}

function rendirse() {
  acciones.style.display = 'none';
  setTimeout(() => {
    nuevaCarta(manoVs);
    verify();
    fin = true;
  }, 1000);
}

/* Hacer apuesta */

coins.forEach(coin => {
  coin.addEventListener('click', () => {
    if (localStorage.saldo >= parseFloat(coin.classList[0])) {
      apostado += parseFloat(coin.classList[0]);
      localStorage.saldo -= parseFloat(coin.classList[0]);
      apuestaPrevia.textContent = '€' + apostado;
      update();
    }
  });
});

function comenzar() {
  if (apostado > 0) {
    if (localStorage.saldo < 500) {
      let confirmar = confirm(`Seguro que quieres apostar? Solo te quedan €${localStorage.saldo}`);
      if (confirmar === false) {
        return;
      }
    }
    disabled(hacerApuesta);
    coinApostado.textContent = apostado;
    setTimeout(() => {
      nuevaCarta(mano);
    }, 600);
    setTimeout(() => {
      nuevaCarta(manoVs);
    }, 1200);
    setTimeout(() => {
      nuevaCarta(mano);
    }, 1800);
    setTimeout(() => {
      nuevaCarta(manoVs);
    }, 2400);
  } else {
    alert('Apuesta mínima €50');
  }
}

/* Nueva carta */

const values = ['A', 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K'];

function nuevaCarta(fat) {
  conteo++;
  reverso.style.transform = 'scale(1.1)';
  setTimeout(() => {
    reverso.style.transform = 'scale(1)';
  }, 200);
  let value = Math.ceil(Math.random() * 13);
  let symbol = Math.ceil(Math.random() * 4);
  let carta = document.createElement('DIV');
  carta.classList.add('carta');
  carta.innerHTML = `
    <span class="value normal">${values[value]}</span> 
    <span class="symbol">${symbols[symbol]}</span> 
    <span class="value rotate">${values[value]}</span> 
    <span class="firma">BayronE.</span>
  `;
  fat.appendChild(carta);
  if (fat === mano) {
    cartaPosX += 4;
    carta.style.left = `${cartaPosX}rem`;
    sumado += value;
  } else {
    carta.style.left = `${cartaVsPosX}rem`;
    cartaVsPosX += 4;
    sumadoVs += value;
  }
  valorSumado.textContent = sumado;
  valorSumadoVs.textContent = sumadoVs;
  if (conteo === 4) {
    verify();
  }
}

function verify() {
  if (sumadoVs !== 21 && sumado !== 21) {
    if (sumadoVs > 21 && sumado > 21) {
      pierde('Ambos Pierden');
    } else {
      if (sumadoVs > 21 || sumado > 21) {
        if (sumadoVs > 21) {
          gana('Se Pasa!!! Tu oponente pierde');
        } else {
          pierde('Se Pasa!!! Tu pierdes');
        }
      } else {
        if (sumado < 21 && sumadoVs < 21) {
          if (fin === false) {
            status.textContent = 'Deside...';
            acciones.style.display = 'flex';
          } else {
            if (sumado === sumadoVs) {
              empate();
            } else {
              if (sumado > sumadoVs) {
                gana('Te acercas más, tú ganas');
              } else {
                pierde('Pierdes, android se acerca más');
              }
            }
          }
        }
      }
    }
  } else {
    if (sumadoVs === 21 && sumado === 21) {
      empate();
    } else {
      if (sumado === 21 || sumadoVs === 21) {
        if (sumado === 21) {
          gana('BlackJack!!!');
        } else {
          pierde('BlackJack!!!, Android Gana');
        }
      } else {}
    }
  }
}
/* if (fat === mano) {
    console.log('Mano');
    sumado += value;
    valorSumado.textContent = 'Sumado: ' + sumado;
    if (sumado < 21) { // Continuar Jugando
      acciones.style.display = 'flex';
      status.textContent = 'Deside...';
    }
    if (sumado === 21) { // Gana
      status.textContent = 'BlackJack!';
      localStorage.saldo = parseFloat(localStorage.saldo) + parseFloat(apostado * 2);
      setTimeout(() => {
        alert(`Ganas ${apostado*2}, Toca aquí para continuar`);
        restart();
      }, 1000)
    }
    if (sumado > 21) { // Se pasa
      status.textContent = 'Se Pasa';
      setTimeout(() => {
        alert(`Perdiste, Toca aquí para continuar`);
        restart();
      }, 1000);
    }
  } else {
    console.log('ManoVs');
    vs(value);
  }

function vs(value) {
  sumadoVs += value;
  valorSumadoVs.textContent = sumadoVs;
  if (sumadoVs > 21) {
    // Se pasa
    status.textContent = 'Tu opomente Pierde!';
    localStorage.saldo = parseFloat(localStorage.saldo) + parseFloat(apostado * 2);
    setTimeout(() => {
      alert(`Ganas ${apostado*2}, Toca aquí para continuar`);
      restart();
    }, 1000)
  }
  if (sumadoVs === 21) {
    // Vs Gana
    status.textContent = 'BlackJack!';
    setTimeout(() => {
      alert(`Perdiste, Toca aquí para continuar`);
      restart();
    }, 1000);
  }
  if (sumadoVs < 21) {
    // Pedir
    nuevaCarta(manoVs);
  }
} */

/*   <div class="carta">
    <span class="value">9</span>
    <span class="symbol">♠</span>
    <span class="value rotate">9</span>
    <span class="firma">BayronE.</span>
    <!--♠♣♥♦-->
  </div>
 */